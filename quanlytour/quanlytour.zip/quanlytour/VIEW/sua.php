<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sửa thông tin</title>
    <link rel="icon" type="image/png" href="../uploads/icon1.png">
    <link rel="stylesheet" href="css/formdangkythongtin.css">
</head>
<body>
    <?php
        include ("../MODEL/model.php");
        $data = new UserModel();
        $sua = $data -> select_user_by_id($_GET['user_id']);
        foreach ($sua as $row){
    ?>
    <form action="../CONTROLLER/xuly.php?user_id=<?php echo $row['id']?>" method="POST">
        Họ tên <input type="text" placeholder="Nhập họ và tên" name="hoten" value="<?php echo $row['hoten']?>" required><br>
        Email <input type="email" placeholder="Nhập email của bạn" name="email" value="<?php echo $row['email']?>" required><br>
        Số điện thoại <input type="number" placeholder="Nhập số điện thoại" name="sodienthoai" value="<?php echo $row['sodienthoai']?>" required><br>
        Mật khẩu <input type="password" placeholder="Nhập mật khẩu" name="matkhau" value="<?php echo $row['matkhau']?>" required><br>
        Tour 
        <select name="select_tour" id="">
            <option value="<?php echo $row['tour']?>"><?php echo $row['tour']?></option>
            <option value="Bắc Ninh - Hà Nội">Bắc Ninh - Hà Nội</option>
            <option value="Mỹ - Việt Nam">Mỹ - Việt Nam</option>
            <option value="Hà Nội - Hà Nam">Hà Nội - Hà Nam</option>
            <option value="Bắc Giang - Địa ngục">Bắc Giang - Địa ngục</option>
        </select><br>
        <input type="submit" value="Sửa thông tin" name="btnsua">
    </form>
    <?php
        }
    ?>
</body>
</html>