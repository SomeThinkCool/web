<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thông tin khách hàng</title>
    <link rel="icon" type="image/png" href="../uploads/icon1.png">
    <style>
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background-image: url('path-to-your-background.jpg'); /* thay bằng ảnh nền của bạn nếu chưa có */
        background-size: cover;
        background-position: center;
        margin: 0;
        padding: 0;
    }

    h1 {
        text-align: center;
        margin-top: 40px;
        color:rgb(255, 0, 0);
        text-shadow: 1px 1px 3px #000;
    }

    table {
        width: 90%;
        margin: 30px auto;
        border-collapse: collapse;
        background-color: rgba(255, 255, 255, 0.95);
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        border-radius: 10px;
        overflow: hidden;
    }

    th, td {
        padding: 15px;
        text-align: center;
        border-bottom: 1px solid #ddd;
    }

    th {
        background-color: #4CAF50;
        color: white;
        font-size: 16px;
    }

    tr:hover {
        background-color: #f1f1f1;
    }

    td a {
        display: inline-block;
        padding: 6px 12px;
        margin: 0 5px;
        text-decoration: none;
        background-color: #2196F3;
        color: white;
        border-radius: 5px;
        transition: 0.3s;
    }

    td a:hover {
        background-color: #0b7dda;
    }
</style>

</head>
<body>
    <?php
        include ("../MODEL/model.php");
        $data = new UserModel();
        $select_user = $data -> select_user();
        echo "<h1>Thông tin khách hàng ^_^</h1>";
        echo "<table>";
        echo "<tr>";
        echo "<th>Họ và tên</th>";
        echo "<th>Email</th>";
        echo "<th>Số điện thoại</th>";
        echo "<th>Mật khẩu</th>";
        echo "<th>Tour</th>";
        echo "<th>Thao tác</th>";
        echo "</tr>";
        foreach ($select_user as $row){
            echo "<tr>";
            echo "<td>".$row['hoten']."</td>";
            echo "<td>".$row['email']."</td>";
            echo "<td>".$row['sodienthoai']."</td>";
            echo "<td>".$row['matkhau']."</td>";
            echo "<td>".$row['tour']."</td>";
            echo "<td><a href='sua.php?user_id=".$row['id']."'>Sửa</a><a href='xoa.php?user_id=".$row['id']."'>Xóa</a></td>";
            echo "</tr>";
        }
        echo "</table>";
    ?>
</body>
</html>