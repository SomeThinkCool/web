<?php
    include ("../MODEL/model.php");
?>
<?php
    include ("../MODEL/connect.php");
    if (isset($_POST['btndangky'])){
        $data = new UserModel();
        global $conn;
        $sql = "SELECT * FROM thongtin WHERE email = '".$_POST['email']."'";
        $run = mysqli_query($conn, $sql);
        if (mysqli_num_rows($run) >= 1){
            echo "<script>alert('Email đã có người dùng, vui lòng đổi Email ^_^'); window.history.back()</script>";
        }
        else{
            $dangky = $data -> dangky($_POST['hoten'], $_POST['email'], $_POST['sodienthoai'], $_POST['matkhau'], $_POST['select_tour']);
            if ($dangky ){
                echo "<script>alert('Bạn đăng ký thành công'); window.location.href='../VIEW/formhienthithongtin.php'</script>";
            }
            else{
                echo "<script>alert('Bạn đăng ký thất bại!!!'); window.history.back()</script>";
            }
        }
        
    }
?>
<?php
    $data = new UserModel();
    if (isset($_POST['btnsua'])){
        $sua = $data -> suathongtin($_GET['user_id'], $_POST['hoten'], $_POST['email'], $_POST['sodienthoai'], $_POST['matkhau'], $_POST['select_tour']);
        if ($sua){
            echo "<script>alert('Bạn sửa thành công'); window.location.href='../VIEW/formhienthithongtin.php'</script>";
        }
        else{
            echo "<script>alert('Bạn sửa thất bại!!!'); window.history.back()</script>";
        }
    }
?>