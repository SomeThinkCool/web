<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $databasename = "quanlytour";

    $conn = mysqli_connect($servername, $username, $password, $databasename);
?>