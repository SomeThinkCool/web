<?php
    include ("connect.php");
    class UserModel{
        public function dangky($hoten, $email, $sodienthoai, $matkhau, $tour){
            global $conn;
            $sql = "INSERT INTO thongtin(hoten, email, sodienthoai, matkhau, tour) 
            VALUES ('$hoten', '$email', '$sodienthoai', '$matkhau', '$tour')";
            $run = mysqli_query($conn, $sql);
            return $run;
        }
        public function select_user(){
            global $conn;
            $sql = "SELECT * FROM thongtin";
            $run = mysqli_query($conn, $sql);
            return $run;
        }
        public function select_user_by_id($id){
            global $conn;
            $sql = "SELECT * FROM thongtin WHERE id = '$id'";
            $run = mysqli_query($conn, $sql);
            return $run;
        }
        public function suathongtin($id, $hoten, $email, $sodienthoai, $matkhau, $tour){
            global $conn;
            $sql = "UPDATE thongtin SET hoten='$hoten', email='$email', sodienthoai='$sodienthoai', matkhau='$matkhau', tour='$tour' WHERE id = '$id'";
            $run = mysqli_query($conn, $sql);
            return $run;
        }
        public function xoa_user($id){
            global $conn;
            $sql = "DELETE FROM thongtin WHERE id = '$id'";
            $run = mysqli_query($conn, $sql);
            return $run;
        }
    }
?>